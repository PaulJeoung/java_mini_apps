package midterm01;

public class PetTestEx08 {

	public static void main(String[] args) {
		Pet kurt = new Pet("Kurt", "아이");
		kurt.introduce();
		System.out.println();
		
		RobotPet r2d2 = new RobotPet("R2d2", "루크");
		r2d2.introduce();
		System.out.println();

	}

}
